/*
 * exit_handler.h: Defines prototype for exit_handler()
 *
 * Author: Harry Q Bovik <hqbovik@andrew.cmu.edu>
 * Date:   Tue, 23 Oct 2007 11:20:33 -0400
 */

#ifndef EXIT_HANDLER_H
#define EXIT_HANDLER_H

void exit_handler(int exit_status);

#endif /* EXIT_HANDLER_H */
